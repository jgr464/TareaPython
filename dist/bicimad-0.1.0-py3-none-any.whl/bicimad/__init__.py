import truststore

truststore.inject_into_ssl()
